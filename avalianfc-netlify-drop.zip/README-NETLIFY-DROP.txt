AVALIA NFC — PACOTE NETLIFY DROP

Este pacote contém a saída estática do frontend, com index.html na raiz,
pronta para arrastar no Netlify Drop.

IMPORTANTE:
O sistema completo Avalia NFC usa backend Express, API tRPC, autenticação
por senha e banco MySQL. O Netlify Drop hospeda apenas arquivos estáticos;
por isso, neste pacote a interface visual abre, mas CRUD de placas, login,
geração de PDFs/ZIP e redirecionamentos dinâmicos não funcionarão sem o
backend publicado separadamente.

Para funcionamento completo, hospede o projeto full-stack em uma plataforma
que execute Node.js e banco, como Render, Railway, Fly.io, VPS ou o próprio
ambiente WebDev. Depois configure o domínio para o backend e as variáveis
necessárias.
